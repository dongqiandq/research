extern void loadData(char*);
extern void loadSequence(int,char*);
extern void FreeBuffer();
