These are batch files we used in our experiments.
