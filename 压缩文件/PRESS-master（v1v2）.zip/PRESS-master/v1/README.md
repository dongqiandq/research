PRESS version 1 is the original programs we used in our experiments.
However, the programs are not well written because of time limit. So there might be difficulty for you using our programs.
Don't worry, we are working on rewritting the whole project in order for you to use our program easily and compare with your approaches of trajectory compression on road networks.
