extern double circleDistance(double, double, double, double);
extern double nodeToEdgeDistanceAndNodeSide(double,double, int, double*, double*);
extern double H_GetShortestPathLength(int, int, double, int *);
