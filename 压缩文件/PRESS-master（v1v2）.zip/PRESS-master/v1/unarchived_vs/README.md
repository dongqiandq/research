These are most of those files included in Visual Studio Project to use its 64bit feature (bigger memory access).
