extern void coreDP(int, long double[][500], int[], int[][500], double[][500], double[][500], int[][500]);
