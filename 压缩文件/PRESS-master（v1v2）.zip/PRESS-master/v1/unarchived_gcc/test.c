#include <stdio.h>

int x;
double y;
int main() {
	scanf("%d %lf",&x,&y);
	printf("%d %lf\n",x,y);
	return 0;
}