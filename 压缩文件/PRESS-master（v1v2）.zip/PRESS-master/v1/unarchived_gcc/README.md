These are most of those source code compiled by 32-bit gcc.
