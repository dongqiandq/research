javac Interval.java
java Interval 20081023025304-0.plt 0.2
