g++ Dead_Reckoning.cpp -o Dead_Reckoning
./Dead_Reckoning 20081023025304-0.plt 0.006 20081023025304-0.csv
