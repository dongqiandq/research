

/**
 * @author Lin (linxl@buaa.edu.cn)
 *
 */
public class GPSPoint {
		int  index =0;				//point id. for debug.
		int  lineId =0;			//the line id that the point compressed into. for debug and test
	    
		double longitude;     	
	    double latitude;        
	    String   time;       
}
