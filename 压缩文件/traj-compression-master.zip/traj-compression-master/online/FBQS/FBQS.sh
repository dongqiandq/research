python amnesic_bubbling.py 20081023025304-0.plt 0.00025
