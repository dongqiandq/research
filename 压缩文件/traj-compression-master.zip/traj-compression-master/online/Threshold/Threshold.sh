g++ Threshold.cpp -o Threshold
./Threshold 20081023025304-0.plt  25 0.8 2 20081023025304-0.csv
