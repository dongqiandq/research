g++ Uniform.cpp -o Uniform 
./Uniform 20081023025304-0.plt 5 20081023025304-0.csv
