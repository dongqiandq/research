g++ -std=c++11 STTrace.cpp -o STTrace
./STTrace 20081023025304-0.plt 0.2 20081023025304-0.csv

