## User Defined
This folder provides an easy way for users to write customized data loading implementations. Take a look at factory.hpp, factory.cpp and search for [USER DEFINE] tags. Then take a look at each subfolder.
You can follow the examples to write your own logic to load your own data (graph/roadnet, gps trajectory, etc) with whatever format.
