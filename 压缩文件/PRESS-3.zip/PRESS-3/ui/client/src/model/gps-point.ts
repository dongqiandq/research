export interface GPSPoint {
  LAT: number;
  LONG: number;
  T: number;
}
