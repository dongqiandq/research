import { Position } from "./position";

export type Shape = Position[];
