export interface RoadnetDataSource {
  filename: string;
  roadnetReader?: string;
}
