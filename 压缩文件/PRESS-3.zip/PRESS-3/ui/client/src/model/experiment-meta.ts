export interface ExperimentMeta {
  id: number;
  name: string;
  creationTime: number;
  image: string;
};
