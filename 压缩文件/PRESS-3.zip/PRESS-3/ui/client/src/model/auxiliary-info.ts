export interface AuxiliaryInfo {
  filename: string;
  size: number;
}
