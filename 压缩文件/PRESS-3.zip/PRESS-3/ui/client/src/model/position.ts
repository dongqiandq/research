export interface Position {
  Lat: number;
  Long: number;
}
