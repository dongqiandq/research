export type GeoPath = [number, number][];
