export interface DTPair {
  D: number;
  T: number;
}
