export interface GPSFolderSource {
  sourceName: string;
  folderName: string;
  gpsReader?: string;
};
