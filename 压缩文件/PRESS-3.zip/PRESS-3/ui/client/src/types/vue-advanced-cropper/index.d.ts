declare module 'vue-advanced-cropper';
